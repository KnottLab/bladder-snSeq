#!/usr/bin/env bash

circos -conf config.conf -outputfile Fibroblast.svg -debug_group textplace
