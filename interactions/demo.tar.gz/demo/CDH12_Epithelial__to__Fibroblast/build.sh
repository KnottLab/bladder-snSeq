#!/usr/bin/env bash

circos -conf config.conf -outputfile demo.svg -debug_group textplace
