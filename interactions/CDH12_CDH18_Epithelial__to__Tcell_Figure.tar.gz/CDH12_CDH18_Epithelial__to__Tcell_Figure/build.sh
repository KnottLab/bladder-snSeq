#!/usr/bin/env bash

circos -conf config.conf -outputfile Tcells.svg -debug_group textplace
